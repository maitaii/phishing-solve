#!/bin/bash

pkill -f 'solvefish.py'
python3 solvefish.py
pkill -f 'solvefish.py'
