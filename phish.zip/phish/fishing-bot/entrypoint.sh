rq worker --with-scheduler --url redis://redis:6379 &
python3 /app/main.py
